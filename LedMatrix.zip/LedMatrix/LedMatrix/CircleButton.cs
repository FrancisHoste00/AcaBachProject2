﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace LedMatrix
{
    public class CircleButton : Button
    {
        protected override void OnCreateControl() {
            GraphicsPath gr = new GraphicsPath();
            gr.AddEllipse(3, 3, 20, 20);
            this.Size = new Size(27,27);
            this.BackColor = Color.Black;
            this.Region = new System.Drawing.Region(gr);
            base.OnCreateControl();     
        }
    }
}
