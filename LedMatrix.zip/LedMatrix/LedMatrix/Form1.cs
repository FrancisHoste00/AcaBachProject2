﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace LedMatrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// //////////////////////////////////////////////////////////////////////////////////////
        CircleButton[,] ledMatrix;
        private CircleButton[,] MatrixInit(int row, int col, Panel panel) {
            CircleButton[,] cbmatrix = new CircleButton[row, col];
            Label[] rowLabel = new Label[16];
            Label[] colLabel = new Label[32];
            int rowCtr = 1;
            int colCtr = 1;
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    if (j == 0) {
                        rowLabel[i] = new Label();
                        rowLabel[i].Parent = panel;
                        rowLabel[i].Location = new Point( 2, 27 + (i*24));
                        rowLabel[i].Text = "" + rowCtr;
                        rowLabel[i].TextAlign = ContentAlignment.MiddleLeft;
                        rowLabel[i].Size = new Size(24, 24);
                        rowLabel[i].Font = new Font(rowLabel[i].Font.FontFamily, 7);
                        rowLabel[i].BorderStyle = BorderStyle.FixedSingle;
                        rowCtr++;
                    }
                    if (i == 0)
                    {
                        colLabel[j] = new Label();
                        colLabel[j].Parent = panel;
                        colLabel[j].Location = new Point(27 + ( j*24), 2);
                        colLabel[j].Text = "" + colCtr;
                        colLabel[j].TextAlign = ContentAlignment.MiddleCenter;
                        colLabel[j].Size = new Size(24, 24);
                        colLabel[j].Font = new Font(colLabel[j].Font.FontFamily, 7);
                        colLabel[j].BorderStyle = BorderStyle.FixedSingle;
                        colCtr++;
                    }

                    cbmatrix[i, j] = new CircleButton();
                    cbmatrix[i, j].Parent = panel;
                    cbmatrix[i, j].Location = new Point(((j * 24) + 25), ((i * 24) + 25));
                    cbmatrix[i, j].Click += MatrixButton_Click;
                }
            }
            return cbmatrix;
        }

        private byte ColorByte(Color col) {
            byte r, g, b;
            if (col.R == 255)
            {
                r = 3;
            }
            else {
                r = 0;
            }
            if (col.G == 255)
            {
                g = 12;
            }
            else
            {
                g = 0;
            }
            if (col.B == 255)
            {
                b = 48;
            }
            else
            {
                b = 0;
            }

            return (byte)(r + g + b);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ledMatrix = MatrixInit(16, 32, panel1);
            checkBox1.Appearance = Appearance.Button;
            checkBox2.Appearance = Appearance.Button;
            checkBox3.Appearance = Appearance.Button;
        }

        private void MatrixButton_Click(object sender, EventArgs e) {
            CircleButton cb = sender as CircleButton;
            cb.BackColor = pictureBox1.BackColor;
        }

        private void ColorCb_Changed(object sender, EventArgs e) {
            CheckBox cb = sender as CheckBox;
            int r = 0;
            int g = 0;
            int b = 0;
            if (cb.Checked)
            {
                cb.Text = "ON";
                cb.ForeColor = Color.Black;
                cb.BackColor = Color.Red;
            }
            else {
                cb.Text = "OFF";
                cb.ForeColor = Color.White;
                cb.BackColor = Color.Black;
            }
            if (checkBox1.Checked)
            {
                r = 255;
            }
            else {
                r = 0;
            }
            if (checkBox2.Checked)
            {
                g = 255;
            }
            else
            {
                g = 0;
            }
            if (checkBox3.Checked)
            {
                b = 255;
            }
            else
            {
                b = 0;
            }
            pictureBox1.BackColor = Color.FromArgb(r, g, b);
        }

        private void Resetcb_Click(object sender, EventArgs e)
        {
            foreach (CircleButton cb in ledMatrix) {
                cb.BackColor = Color.Black;
            }
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
        }

        private void ColorFullcb_Click(object sender, EventArgs e)
        {
            foreach (CircleButton cb in ledMatrix)
            {
                cb.BackColor = pictureBox1.BackColor;
            }
        }

        private void transmitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                TcpClient client = new TcpClient();
                string ip = textBox1.Text + "." + textBox2.Text + "." + textBox3.Text + "." + textBox4.Text;
                int port = Convert.ToInt32(textBox5.Text);
                client.Connect(ip, port);
                Stream strm = client.GetStream();
                string sentValues = "";
                byte[] colByte = new byte[512];
                int i = 0;
                foreach (CircleButton cb in ledMatrix)
                {
                    colByte[i] = ColorByte(cb.BackColor);
                    if ((i + 1) % 32 == 0)
                        sentValues = sentValues + colByte[i].ToString() + "\r\n";
                    else
                        sentValues = sentValues + colByte[i].ToString() + " ";
                    i++;
                }
                strm.Write(colByte, 0, colByte.Length);
                client.Close();

                richTextBox1.Text = sentValues;
            }
            catch (Exception ex) {
                DialogResult result = MessageBox.Show("Could not connect! \r\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfd = new OpenFileDialog();
            openfd.Filter = "Images|*.jpg; *.gif; *.bmp; *.png";
            if (openfd.ShowDialog() == DialogResult.OK) {
                textBox6.Text = openfd.FileName;
                pictureBox2.Image = Image.FromFile(textBox6.Text);
                pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void setImage_Click(object sender, EventArgs e)
        {
            if (checkBox4.Checked) {
                setImage2();
                return;
            }
            Image im = pictureBox2.Image;
            Bitmap pic = new Bitmap(im, 32, 16);
            int i = 0;
            foreach (CircleButton cb in ledMatrix)
            {
                
                Color cl = pic.GetPixel((i % 32), (i / 32));
                int r = 0;
                int g = 0;
                int b = 0;
                if (cl.R > 125)
                {
                    r = 255;
                }
                else
                {
                    r = 0;
                }
                if (cl.G > 125)
                {
                    g = 255;
                }
                else
                {
                    g = 0;
                }
                if (cl.B > 125)
                {
                    b = 255;
                }
                else
                {
                    b = 0;
                }
                pic.SetPixel((i % 32), (i / 32), Color.FromArgb(r, g, b));
                cb.BackColor = pic.GetPixel((i % 32), (i / 32));
                i++;
            }
        }

        private void saveBitmap_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Images| *.png";
            if (sfd.ShowDialog() == DialogResult.OK) {
                Bitmap bm = new Bitmap(32, 16);
                int i = 0;
                foreach (CircleButton cb in ledMatrix)
                {
                    bm.SetPixel((i % 32), (i / 32), cb.BackColor);
                    i++;
                }
                bm.Save(sfd.FileName);
            }
        }

        private void setImage2()
        {
            Image im = pictureBox2.Image;
            double scale = Math.Max(1 + im.Height / 16, 1 + im.Width / 32);
            Bitmap pic = new Bitmap(im, Convert.ToInt32(im.Width / scale), Convert.ToInt32(im.Height / scale));
            UInt16 heightMove = Convert.ToUInt16(((16 - pic.Height) / 2));
            UInt16 widthMove = Convert.ToUInt16(((32 - pic.Width) / 2));
            int i = 0;
            Color cl;
            int r;
            int g;
            int b;
            foreach (CircleButton cb in ledMatrix)
            {
                cb.BackColor = Color.FromArgb(0, 0, 0);
                if ((i / 32) >= pic.Height + heightMove || (i % 32) >= pic.Width + widthMove ||
                    (i / 32) < heightMove || (i % 32) < widthMove)
                {
                    cb.BackColor = Color.FromArgb(0, 0, 0);
                    i++;
                    continue;
                }
                else
                {
                    cl = pic.GetPixel((i % 32) - widthMove, (i / 32) - heightMove);
                }
                if (cl.R > 255 - trackBar1.Value)
                {
                    r = 255;
                }
                else
                {
                    r = 0;
                }
                if (cl.G > 255 - trackBar2.Value)
                {
                    g = 255;
                }
                else
                {
                    g = 0;
                }
                if (cl.B > 255 - trackBar3.Value)
                {
                    b = 255;
                }
                else
                {
                    b = 0;
                }
                //pic.SetPixel((i % 32)+widthMove, (i / 32)+heightMove, Color.FromArgb(r, g, b));
                //cb.BackColor = pic.GetPixel((i % 32), (i / 32));
                cb.BackColor = Color.FromArgb(r, g, b);
                i++;
            }
        }


        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            label12.Text = "G: " + trackBar2.Value.ToString();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label11.Text = "R: " + trackBar1.Value.ToString();
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
             label13.Text = "B: " + trackBar3.Value.ToString();
        }

    }
}
