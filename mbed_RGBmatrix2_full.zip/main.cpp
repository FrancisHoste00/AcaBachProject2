#include "mbed.h"
#include "EthernetInterface.h"
#define LOW 0
#define HIGH 1
#define ip "10.0.99.102"
#define subnet "255.255.255.0"
#define gateway "10.0.99.101"
#define port 4001

EthernetInterface eth;
TCPSocketServer tcpserver;
TCPSocketConnection client;
BusOut ABC(p24,p25,p26); // Row address.
BusOut RGB1(p27, p27, p29, p29 , p19, p19);
BusOut RGB2(p28, p28 , p30, p30, p18, p18);
DigitalOut CLK(p21);    //  Data clock    - rising edge
DigitalOut LAT(p22);    //  Data latch    - active low (pulse up after data load)
DigitalOut OE(p23);     //  Output enable - active low (hold high during data load, bring low after LAT pulse)
AnalogIn   ain(p20);    // p20 or GND to disable
DigitalIn joy(p14);     // p14

// array which is painted on board
// values in bytes
// two bits for each color
// xxBBGGRR
unsigned char gm[16][32]; //2D array which is used as graphic memory

/*
Function which writes the data to the specified row.
The row is then latched to the display. 
*/
void WrRow(unsigned char row)
{
    ABC = row;
    // for each pixel in line set its color
    for(int col=0; col < 32; col++) { 
        RGB1 = gm[row][col];
        RGB2 = gm[row+8][col];
        // pixel set impuls
        CLK = HIGH;
        CLK = LOW;                  
    }
    // end of line impuls
    LAT = HIGH; 
    LAT = LOW;
}

/*
Function that shows the latched data on the screen line by line
*/
void PaintPicture()
{
    for(int Row=0; Row<8; Row++) {
            WrRow(Row);//WrRow(Row,bright);
            OE = LOW; // Enable output
            wait_us(500);
            OE = HIGH; // Disable output
    }
}
 
/*
Function which initializes the display to a know state. (Display off)
*/
void Init()
{
    CLK = LOW;
    LAT = LOW;
    OE = HIGH; //display off
    
    // clear output
    ABC = 0;
    memset(gm, 0, sizeof(gm));
    PaintPicture();
}

int main() {
    // ethernet port connect
    char rxdata[512];
    eth.init(ip, subnet, gateway);
    eth.connect();
    tcpserver.bind(port);
    tcpserver.set_blocking(false, 0);
    tcpserver.listen();
    Init(); 
    while (true) {
        tcpserver.accept(client);
        while(client.is_connected()){
            client.receive(rxdata, 512);
            for(int i = 0; i < 512; i++){
                gm[i/32][i%32]=rxdata[i];
            }  
        }
        
        client.close(); 
        
        // update whole picture
        PaintPicture();
        
        // bright set
        wait_us(12500 * ain.read());
        
        // cleare screen with joy
        if(joy)
        {
            Init();
            while(joy);
         }
    }
}